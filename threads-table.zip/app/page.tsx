"use client"

import { useState, useEffect } from "react"
import { Twitter, Linkedin, Instagram, ArrowUp, ArrowDown, ExternalLink, Images } from "lucide-react"
import { ThreadDetailModal } from "@/components/thread-detail-modal"
import { CarouselModal } from "@/components/carousel-modal"
import { VideoIdeasQueue } from "@/components/video-ideas-queue"
import type { Thread } from "@/types/thread"

type Platform = "twitter" | "linkedin" | "instagram"

export default function ThreadsPage() {
  const [threads, setThreads] = useState<Thread[]>([])
  const [loading, setLoading] = useState(true)
  const [activePlatform, setActivePlatform] = useState<Platform>("twitter")
  const [selectedThread, setSelectedThread] = useState<Thread | null>(null)
  const [carouselThread, setCarouselThread] = useState<Thread | null>(null)
  const [sortColumn, setSortColumn] = useState<"views" | "likes" | "replies" | "date" | "">("")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")
  const [username, setUsername] = useState<string>("User")

  useEffect(() => {
    const fetchThreads = async () => {
      setLoading(true)
      try {
        const response = await fetch("http://127.0.0.1:5000/api/threads/43122230")
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        const threadsData: Thread[] = await response.json()

        // Extract username from the first thread if available
        if (threadsData.length > 0 && threadsData[0].client_id) {
          setUsername(threadsData[0].client_id)
        }

        // Update threads with statistics and title from the first tweet
        const updatedThreads = threadsData.map((thread) => {
          if (thread.tweets.length > 0) {
            const firstTweet = thread.tweets[0]
            return {
              ...thread,
              title: firstTweet.text.split("\n")[0], // First line of the first tweet
              likes: firstTweet.like_count,
              replies: firstTweet.reply_count,
              views: firstTweet.view_count || 0, // Assuming view_count is available
              date: firstTweet.date_posted,
            }
          }
          return thread
        })

        setThreads(updatedThreads)
      } catch (error) {
        console.error("Failed to fetch threads:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchThreads()
  }, [])

  const handleThreadSelect = (thread: Thread) => {
    setSelectedThread(thread)
  }

  const handleCarouselSelect = (thread: Thread) => {
    setCarouselThread(thread)
  }

  const handleRepackagedChange = (platform: "linkedin" | "instagram", value: boolean) => {
    if (selectedThread) {
      // In a real app, you would update the thread in your database
      console.log(`Updated ${platform} repackaged status to ${value} for thread ${selectedThread.id}`)
    }
  }

  const handleSort = (column: "views" | "likes" | "replies" | "date" | "") => {
    if (sortColumn === column) {
      // Flip direction
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"))
    } else {
      setSortColumn(column)
      setSortDirection("desc")
    }
  }

  const sortedThreads = [...threads].sort((a, b) => {
    if (!sortColumn) return 0

    const valA = sortColumn === "date" ? new Date(a.date).getTime() : (a as any)[sortColumn]
    const valB = sortColumn === "date" ? new Date(b.date).getTime() : (b as any)[sortColumn]

    return sortDirection === "asc" ? valA - valB : valB - valA
  })

  // Calculate total metrics for the dashboard
  const totalViews = threads.reduce((sum, thread) => sum + thread.views, 0)
  const totalLikes = threads.reduce((sum, thread) => sum + thread.likes, 0)
  const totalReplies = threads.reduce((sum, thread) => sum + thread.replies, 0)
  const repackagedCount = threads.filter((t) => t.repackaged_linkedin || t.repackaged_instagram).length

  return (
    <div className="min-h-screen bg-[#15202b] text-white">
      <div className="flex h-screen">
        {/* Sidebar */}
        <div className="w-64 border-r border-[#38444d] p-4 flex flex-col">
          <div className="mb-8">
            <div className="w-10 h-10 bg-[#1d9bf0] rounded-full flex items-center justify-center">
              <Twitter className="h-6 w-6 text-white" />
            </div>
          </div>

          <div className="mb-8">
            <div className="text-xl font-bold mb-4">Jesse Itzler</div>
            <div className="text-xl font-bold text-[#8899a6]">Daniel Pink</div>
          </div>

          <div className="mt-auto">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gray-500 rounded-full mr-3"></div>
              <div>
                <div className="font-bold">Account</div>
                <div className="text-[#8899a6] text-sm">@username</div>
              </div>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-auto">
          <div className="p-8">
            {/* Welcome Header - Made larger and more prominent */}
            <h1 className="text-3xl font-bold mb-8">Welcome {username}</h1>

            {/* Platform Tabs - Increased spacing */}
            <div className="flex border-b border-[#38444d] mb-10">
              <button
                className={`px-8 py-4 font-medium text-base flex items-center ${
                  activePlatform === "twitter"
                    ? "text-[#1d9bf0] border-b-2 border-[#1d9bf0]"
                    : "text-[#8899a6] hover:text-white"
                }`}
                onClick={() => setActivePlatform("twitter")}
              >
                <Twitter className="h-5 w-5 mr-2" />
                Twitter
              </button>
              <button
                className={`px-8 py-4 font-medium text-base flex items-center ${
                  activePlatform === "linkedin"
                    ? "text-[#0A66C2] border-b-2 border-[#0A66C2]"
                    : "text-[#8899a6] hover:text-white"
                }`}
                onClick={() => setActivePlatform("linkedin")}
              >
                <Linkedin className="h-5 w-5 mr-2" />
                LinkedIn
              </button>
              <button
                className={`px-8 py-4 font-medium text-base flex items-center ${
                  activePlatform === "instagram"
                    ? "text-[#E4405F] border-b-2 border-[#E4405F]"
                    : "text-[#8899a6] hover:text-white"
                }`}
                onClick={() => setActivePlatform("instagram")}
              >
                <Instagram className="h-5 w-5 mr-2" />
                Instagram
              </button>
            </div>

            {activePlatform === "twitter" && (
              <>
                {/* Dashboard Stats - Larger Version with more padding and spacing */}
                <div className="bg-[#192734] rounded-lg border border-[#38444d] p-8 mb-12">
                  <div className="grid grid-cols-4 gap-8">
                    <div className="border-r border-[#38444d] pr-8 last:border-0">
                      <div className="text-[#8899a6] text-base mb-3">Total Views</div>
                      <div className="text-3xl font-bold mb-2">{totalViews.toLocaleString()}</div>
                      <div className="text-green-500 text-base flex items-center">
                        <ArrowUp className="h-5 w-5 mr-2" />
                        8.2% this week
                      </div>
                    </div>

                    <div className="border-r border-[#38444d] pr-8 last:border-0">
                      <div className="text-[#8899a6] text-base mb-3">Total Likes</div>
                      <div className="text-3xl font-bold mb-2">{totalLikes.toLocaleString()}</div>
                      <div className="text-green-500 text-base flex items-center">
                        <ArrowUp className="h-5 w-5 mr-2" />
                        12.5% this week
                      </div>
                    </div>

                    <div className="border-r border-[#38444d] pr-8 last:border-0">
                      <div className="text-[#8899a6] text-base mb-3">Total Replies</div>
                      <div className="text-3xl font-bold mb-2">{totalReplies.toLocaleString()}</div>
                      <div className="text-red-500 text-base flex items-center">
                        <ArrowDown className="h-5 w-5 mr-2" />
                        3.1% this week
                      </div>
                    </div>

                    <div>
                      <div className="text-[#8899a6] text-base mb-3">Repackaged</div>
                      <div className="text-3xl font-bold mb-2">
                        {repackagedCount}/{threads.length}
                      </div>
                      <div className="text-[#8899a6] text-base">threads repackaged</div>
                    </div>
                  </div>
                </div>

                {/* Section Header for Threads */}
                <div className="mb-6">
                  <h2 className="text-2xl font-bold">Your Threads</h2>
                  <p className="text-[#8899a6] mt-2">Manage and track your Twitter threads</p>
                </div>

                {/* Threads Table - Added more padding */}
                <div className="overflow-x-auto rounded-lg bg-[#192734] border border-[#38444d]">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b border-[#38444d] text-left">
                        <th className="p-5 font-medium text-[#8899a6]">Thread</th>
                        <th
                          className="p-5 font-medium text-[#8899a6] cursor-pointer"
                          onClick={() => handleSort("views")}
                        >
                          <div className="flex items-center">
                            Views
                            {sortColumn === "views" && (
                              <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </th>
                        <th
                          className="p-5 font-medium text-[#8899a6] cursor-pointer"
                          onClick={() => handleSort("likes")}
                        >
                          <div className="flex items-center">
                            Likes
                            {sortColumn === "likes" && (
                              <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </th>
                        <th
                          className="p-5 font-medium text-[#8899a6] cursor-pointer"
                          onClick={() => handleSort("replies")}
                        >
                          <div className="flex items-center">
                            Replies
                            {sortColumn === "replies" && (
                              <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </th>
                        <th
                          className="p-5 font-medium text-[#8899a6] cursor-pointer"
                          onClick={() => handleSort("date")}
                        >
                          <div className="flex items-center">
                            Date
                            {sortColumn === "date" && (
                              <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </th>
                        <th className="p-5 font-medium text-[#8899a6] text-center">Platforms</th>
                        <th className="p-5 font-medium text-[#8899a6]" colSpan={2}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr>
                          <td colSpan={8} className="p-5 text-center">
                            <div className="py-8">Loading threads...</div>
                          </td>
                        </tr>
                      ) : (
                        sortedThreads.map((thread) => (
                          <tr
                            key={thread.id}
                            className="border-b border-[#38444d] hover:bg-[#22303c] transition-colors"
                          >
                            <td className="p-5">
                              <div className="line-clamp-1 font-medium">{thread.title}</div>
                            </td>
                            <td className="p-5">{thread.views.toLocaleString()}</td>
                            <td className="p-5">{thread.likes.toLocaleString()}</td>
                            <td className="p-5">{thread.replies.toLocaleString()}</td>
                            <td className="p-5">{thread.date}</td>
                            <td className="p-5">
                              <div className="flex justify-center space-x-4">
                                <Linkedin
                                  className={`h-5 w-5 ${
                                    thread.repackaged_linkedin ? "text-[#0A66C2]" : "text-[#38444d]"
                                  } transition-colors`}
                                />
                                <Instagram
                                  className={`h-5 w-5 ${
                                    thread.repackaged_instagram ? "text-[#E4405F]" : "text-[#38444d]"
                                  } transition-colors`}
                                />
                              </div>
                            </td>
                            <td className="p-5">
                              <button
                                onClick={() => handleCarouselSelect(thread)}
                                className="px-4 py-2 bg-[#38444d] text-white rounded-full text-sm hover:bg-[#4c5a66] transition-colors flex items-center"
                              >
                                <Images className="h-4 w-4 mr-2" />
                                <span>Carousel</span>
                              </button>
                            </td>
                            <td className="p-5">
                              <button
                                onClick={() => handleThreadSelect(thread)}
                                className="px-4 py-2 bg-[#1d9bf0] text-white rounded-full text-sm hover:bg-[#1a91da] transition-colors flex items-center"
                              >
                                <span>View</span>
                                <ExternalLink className="ml-1 w-3 h-3" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Video Ideas Section */}
                <div className="mt-12">
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold">Video Ideas Log</h2>
                    <p className="text-[#8899a6] mt-2">Keep track of content ideas for future videos</p>
                  </div>
                  <VideoIdeasQueue />
                </div>
              </>
            )}

            {activePlatform === "linkedin" && (
              <div className="text-center text-[#8899a6] py-12 bg-[#192734] rounded-lg border border-[#38444d]">
                LinkedIn dashboard will be implemented in the next phase
              </div>
            )}

            {activePlatform === "instagram" && (
              <div className="text-center text-[#8899a6] py-12 bg-[#192734] rounded-lg border border-[#38444d]">
                Instagram dashboard will be implemented in the next phase
              </div>
            )}
          </div>
        </div>
      </div>

      {selectedThread && (
        <ThreadDetailModal
          thread={selectedThread}
          onClose={() => setSelectedThread(null)}
          onRepackagedChange={handleRepackagedChange}
        />
      )}

      {carouselThread && <CarouselModal thread={carouselThread} onClose={() => setCarouselThread(null)} />}
    </div>
  )
}

